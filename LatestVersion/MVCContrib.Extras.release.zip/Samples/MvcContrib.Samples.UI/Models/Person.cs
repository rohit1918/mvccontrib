using System;

namespace MvcContrib.Samples.UI.Models
{
	public class Person
	{
		public string Name { get; set; }
		public int Id { get; set; }
		public string Gender { get; set; }
		public DateTime DateOfBirth { get; set; }
	}
}